/*
See LICENSE folder for this sample’s licensing information.

Abstract:
MarsHabitatPricePredictor app.
*/

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
}
